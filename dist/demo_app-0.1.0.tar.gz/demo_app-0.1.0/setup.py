from setuptools import setup, find_packages

setup(
    name='demo_app',
    version='0.1.0',
    packages=find_packages(),
    author="Mustafa",
    author_email="mustafa.mustafa@domain.com.au",
    description="package for python application",
    install_requires=[
        # List your project dependencies here
    ],
#    entry_points={
#        'console_scripts': [
#            'your_script = your_module.your_script:main',
#        ],
#    },
)
